package edu.emory.mathcs.cs323.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class MathUtilsTest {
	@Test
	public void getMiddleIndexTest()
	{
	    assertEquals(MathUtils.getMiddleIndex(0, 10), 5);
	}
}